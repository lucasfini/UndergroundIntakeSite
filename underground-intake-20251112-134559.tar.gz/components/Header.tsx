'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useState } from 'react'

interface HeaderProps {
  currentPage?: string
}

export const Header: React.FC<HeaderProps> = ({ currentPage = 'home' }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navLinks = [
    { href: '/', label: 'Home', id: 'home' },
    { href: '/prices', label: 'Prices', id: 'prices' },
    { href: '/resources', label: 'Resources', id: 'resources' },
    { href: '/about', label: 'About Us', id: 'about' },
    { href: '/contact', label: 'Contact Us', id: 'contact' },
  ]

  return (
    <>
      {/* Main Navigation */}
      <nav className="bg-white border-b border-gray-200 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="hover:opacity-80 transition -my-4">
            <Image
              src="/images/UG-Logo-Secondary-Colour.svg"
              alt="Underground Design Logo"
              width={300}
              height={300}
              className="w-56 h-56 md:w-64 md:h-64"
            />
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.id}
                href={link.href}
                className={`px-4 py-2 rounded transition ${
                  currentPage === link.id
                    ? 'bg-underground-teal text-white'
                    : 'text-gray-700 hover:text-underground-teal'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Order Now Button - Desktop */}
          <Link
            href="/form"
            className="hidden md:flex bg-underground-teal text-white px-6 py-2 rounded hover:bg-underground-green transition items-center gap-2"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
              />
            </svg>
            ORDER NOW
          </Link>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-gray-700 p-2"
            aria-label="Toggle menu"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              {mobileMenuOpen ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-gray-200">
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <Link
                  key={link.id}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-4 py-3 rounded transition ${
                    currentPage === link.id
                      ? 'bg-underground-teal text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/form"
                onClick={() => setMobileMenuOpen(false)}
                className="bg-underground-teal text-white px-4 py-3 rounded hover:bg-underground-green transition text-center font-medium"
              >
                ORDER NOW
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Hours Banner */}
      <div className="bg-underground-teal text-white py-2 px-6 text-center">
        <p className="text-sm font-medium">
          We are open Monday - Friday | 10am - 4pm
        </p>
      </div>
    </>
  )
}
