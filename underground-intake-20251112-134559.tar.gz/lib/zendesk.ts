interface ZendeskTicket {
  subject: string
  comment: {
    body: string
    uploads?: string[]
  }
  requester: {
    name: string
    email: string
  }
  custom_fields?: Array<{ id: number; value: string }>
  priority?: 'low' | 'normal' | 'high' | 'urgent'
  tags?: string[]
}

interface ZendeskUploadResponse {
  upload: {
    token: string
    attachment: {
      id: number
      file_name: string
      content_url: string
      content_type: string
      size: number
    }
  }
}

async function uploadFileToZendesk(
  filePath: string,
  fileName: string,
  subdomain: string,
  auth: string
): Promise<string | null> {
  try {
    const fs = await import('fs/promises')
    const path = await import('path')

    // Read the file from the filesystem
    const fullPath = path.join(process.cwd(), 'public', filePath)
    const fileBuffer = await fs.readFile(fullPath)

    // Upload to Zendesk
    const uploadResponse = await fetch(
      `https://${subdomain}.zendesk.com/api/v2/uploads.json?filename=${encodeURIComponent(fileName)}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/binary',
          Authorization: `Basic ${auth}`,
        },
        body: fileBuffer,
      }
    )

    if (!uploadResponse.ok) {
      console.error(`Failed to upload ${fileName}:`, await uploadResponse.text())
      return null
    }

    const uploadData: ZendeskUploadResponse = await uploadResponse.json()
    return uploadData.upload.token
  } catch (error) {
    console.error(`Error uploading file ${fileName}:`, error)
    return null
  }
}

export async function createZendeskTicket(data: any): Promise<any> {
  const subdomain = process.env.ZENDESK_SUBDOMAIN
  const email = process.env.ZENDESK_EMAIL
  const apiToken = process.env.ZENDESK_API_TOKEN

  if (!subdomain || !email || !apiToken) {
    throw new Error('Zendesk credentials not configured')
  }

  const auth = Buffer.from(`${email}/token:${apiToken}`).toString('base64')

  // Upload files to Zendesk if any exist
  const uploadTokens: string[] = []

  if (data.uploadedFiles) {
    const allFiles: Array<{ path: string; name: string }> = []

    // Collect logo files
    if (data.uploadedFiles.logos && Array.isArray(data.uploadedFiles.logos)) {
      data.uploadedFiles.logos.forEach((fileName: string) => {
        allFiles.push({
          path: `/uploads/${data.submissionId}/logo-${fileName}`,
          name: fileName,
        })
      })
    }

    // Collect attachment files
    if (data.uploadedFiles.attachments && Array.isArray(data.uploadedFiles.attachments)) {
      data.uploadedFiles.attachments.forEach((fileName: string) => {
        allFiles.push({
          path: `/uploads/${data.submissionId}/attachment-${fileName}`,
          name: fileName,
        })
      })
    }

    // Upload all files to Zendesk
    for (const file of allFiles) {
      const token = await uploadFileToZendesk(file.path, file.name, subdomain, auth)
      if (token) {
        uploadTokens.push(token)
      }
    }
  }

  // Format uploaded files section
  const totalFiles =
    (data.uploadedFiles?.logos?.length || 0) +
    (data.uploadedFiles?.attachments?.length || 0)

  const filesSection = totalFiles > 0 ? `

=== UPLOADED FILES ===
${totalFiles} file(s) attached to this ticket
${uploadTokens.length > 0 ? '(See attachments below)' : '(Upload failed - files saved locally at /uploads/' + data.submissionId + '/)'}
` : ''

  // Format the ticket body
  const ticketBody = `
New Project Request from ${data.name}

=== CONTACT INFORMATION ===
Service: ${data.service}
Name: ${data.name}
Position: ${data.position || 'N/A'}
Email: ${data.email}

=== EVENT DETAILS ===
Event Name: ${data.eventName}
Date: ${data.eventDate}
Time: ${data.time || 'N/A'}
Location: ${data.location || 'N/A'}
Link: ${data.link || 'N/A'}

=== PROJECT DETAILS ===
Call to Action: ${data.callToAction || 'N/A'}

Content:
${data.content}

Additional Information:
${data.additionalInfo || 'N/A'}
${filesSection}
=== PACKAGE & PRICING ===
Selected Package: ${data.selectedPackage?.name || 'None'}
Package Price: $${data.selectedPackage?.price || 0}

Selected Add-Ons:
${
  data.selectedAddOns && data.selectedAddOns.length > 0
    ? data.selectedAddOns.join(', ')
    : 'None'
}

TOTAL ESTIMATED COST: $${data.totalPrice || 0}

---
Submitted via Underground Design Intake Portal
  `.trim()

  // Build custom fields array
  const customFields: Array<{ id: number; value: string | number }> = []

  // Add custom fields if configured
  const addCustomField = (envVar: string | undefined, value: any) => {
    if (envVar && value !== undefined && value !== null && value !== '') {
      const fieldId = parseInt(envVar)
      if (!isNaN(fieldId)) {
        customFields.push({ id: fieldId, value: String(value) })
      }
    }
  }

  // Map essential form data to custom fields (for sidebar display)
  addCustomField(process.env.ZENDESK_FIELD_SERVICE_TYPE, data.service)
  addCustomField(process.env.ZENDESK_FIELD_SELECTED_PACKAGE, data.selectedPackage?.name)
  addCustomField(
    process.env.ZENDESK_FIELD_SELECTED_ADDONS,
    data.selectedAddOns && data.selectedAddOns.length > 0
      ? data.selectedAddOns.join('\n')
      : 'None'
  )
  addCustomField(process.env.ZENDESK_FIELD_TOTAL_PRICE, data.totalPrice)

  const ticket: ZendeskTicket = {
    subject: `Project Request: ${data.eventName} - ${data.name}`,
    comment: {
      body: ticketBody,
      uploads: uploadTokens.length > 0 ? uploadTokens : undefined,
    },
    requester: {
      name: data.name,
      email: data.email,
    },
    priority: 'normal',
    tags: ['intake-portal', 'project-request', data.service],
    custom_fields: customFields.length > 0 ? customFields : undefined,
  }

  const response = await fetch(`https://${subdomain}.zendesk.com/api/v2/tickets.json`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Basic ${auth}`,
    },
    body: JSON.stringify({ ticket }),
  })

  if (!response.ok) {
    const errorText = await response.text()
    console.error('Zendesk API Error:', errorText)
    throw new Error(`Failed to create Zendesk ticket: ${response.status}`)
  }

  return response.json()
}
