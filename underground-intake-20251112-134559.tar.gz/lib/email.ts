export async function sendConfirmationEmail(
  to: string,
  name: string,
  eventName: string,
  ticketId?: string
): Promise<boolean> {
  const apiKey = process.env.EMAIL_API_KEY
  const from = process.env.EMAIL_FROM || 'noreply@undergrounddesign.ca'

  if (!apiKey) {
    console.warn('Email API key not configured. Skipping email confirmation.')
    return false
  }

  // This is a template for SendGrid or Resend
  // You can adapt this based on your email service provider

  const emailBody = `
Hi ${name},

Thank you for submitting your project request for "${eventName}"!

We've received your request and our team will review it shortly. You should hear back from us within 1-2 business days.

${ticketId ? `Your reference number is: ${ticketId}` : ''}

If you have any questions, please contact us at ugmanager@msu.mcmaster.ca.

Best regards,
Underground Design Team
McMaster Student Union

---
This is an automated message. Please do not reply to this email.
  `.trim()

  try {
    // Example for a generic email API
    // Adapt this to your specific email service (SendGrid, Resend, etc.)
    const response = await fetch('https://api.your-email-service.com/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        from,
        to,
        subject: `Project Request Confirmation - ${eventName}`,
        text: emailBody,
      }),
    })

    return response.ok
  } catch (error) {
    console.error('Failed to send confirmation email:', error)
    return false
  }
}
