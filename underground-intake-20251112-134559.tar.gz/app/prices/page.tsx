import Link from 'next/link'
import { Header } from '@/components/Header'

export default function PricesPage() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      <Header currentPage="prices" />

      <div className="flex-1 max-w-4xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-6">Pricing</h1>

        <div className="prose max-w-none">
          <p className="text-lg text-gray-600 mb-8">
            Our pricing information is available when you submit a project request. Each project is unique, and we'll provide you with a detailed quote based on your specific needs.
          </p>

          <div className="bg-underground-teal/10 border-l-4 border-underground-teal p-6 rounded">
            <h2 className="text-xl font-bold text-gray-900 mb-2">Get a Quote</h2>
            <p className="text-gray-700 mb-4">
              Ready to start your project? Fill out our form to see our package options and pricing.
            </p>
            <Link
              href="/form"
              className="inline-block bg-underground-teal text-white px-6 py-3 rounded hover:bg-underground-green transition"
            >
              Start Your Project
            </Link>
          </div>
        </div>
      </div>

      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
