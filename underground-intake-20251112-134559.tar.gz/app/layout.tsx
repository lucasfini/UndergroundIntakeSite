import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Underground Design - Project Request',
  description: 'Submit your design project request to Underground Design',
  icons: {
    icon: '/images/favico.svg',
    shortcut: '/images/favico.svg',
    apple: '/images/favico.svg',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
