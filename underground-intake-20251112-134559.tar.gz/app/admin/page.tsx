'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { TextArea } from '@/components/ui/TextArea'
import { Select } from '@/components/ui/Select'
import type { PricingData, PackageOption, AddOnOption } from '@/lib/types'

export default function AdminPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [pricingData, setPricingData] = useState<PricingData | null>(null)
  const [editingPackage, setEditingPackage] = useState<PackageOption | null>(null)
  const [editingAddOn, setEditingAddOn] = useState<AddOnOption | null>(null)

  useEffect(() => {
    // Check if already authenticated
    const auth = sessionStorage.getItem('admin_auth')
    if (auth === 'true') {
      setIsAuthenticated(true)
      loadPricingData()
    }
  }, [])

  const loadPricingData = async () => {
    try {
      const response = await fetch('/api/admin/pricing')
      const data = await response.json()
      setPricingData(data)
    } catch (error) {
      console.error('Failed to load pricing data:', error)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })

      if (response.ok) {
        sessionStorage.setItem('admin_auth', 'true')
        setIsAuthenticated(true)
        loadPricingData()
      } else {
        alert('Invalid password')
      }
    } catch (error) {
      alert('Authentication failed')
    } finally {
      setIsLoading(false)
    }
  }

  const handleSavePricing = async () => {
    if (!pricingData) return

    setIsLoading(true)
    try {
      const response = await fetch('/api/admin/pricing', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pricingData),
      })

      if (response.ok) {
        alert('Pricing updated successfully!')
      } else {
        alert('Failed to update pricing')
      }
    } catch (error) {
      alert('Error updating pricing')
    } finally {
      setIsLoading(false)
    }
  }

  const updatePackage = (id: string, updates: Partial<PackageOption>) => {
    if (!pricingData) return

    setPricingData({
      ...pricingData,
      packages: pricingData.packages.map((pkg) =>
        pkg.id === id ? { ...pkg, ...updates } : pkg
      ),
    })
  }

  const updateAddOn = (id: string, updates: Partial<AddOnOption>) => {
    if (!pricingData) return

    setPricingData({
      ...pricingData,
      addOns: pricingData.addOns.map((addOn) =>
        addOn.id === id ? { ...addOn, ...updates } : addOn
      ),
    })
  }

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-gray-100 flex items-center justify-center px-6">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-center mb-2">Admin Login</h1>
          <p className="text-center text-gray-600 mb-6">Underground Design Portal</p>

          <form onSubmit={handleLogin}>
            <Input
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <Button
              type="submit"
              isLoading={isLoading}
              className="w-full mt-4"
            >
              Login
            </Button>
          </form>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-underground-teal text-white py-4 px-6 shadow">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Image
              src="/images/UG-Logo-Secondary-Colour.svg"
              alt="Underground Design Logo"
              width={50}
              height={50}
              className="w-12 h-12"
            />
            <div>
              <h1 className="text-2xl font-bold">Admin Dashboard</h1>
              <p className="text-sm opacity-90">Pricing Management</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Button
              variant="secondary"
              onClick={() => router.push('/')}
            >
              View Site
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                sessionStorage.removeItem('admin_auth')
                setIsAuthenticated(false)
              }}
              className="!text-white !border-white hover:!bg-white hover:!text-underground-teal"
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Packages Section */}
        <section className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-2xl font-bold mb-6">Packages</h2>

          <div className="space-y-6">
            {pricingData?.packages.map((pkg) => (
              <div key={pkg.id} className="border border-gray-200 rounded-lg p-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input
                    label="Package Name"
                    value={pkg.name}
                    onChange={(e) =>
                      updatePackage(pkg.id, { name: e.target.value })
                    }
                  />
                  <Input
                    label="Price"
                    type="number"
                    value={pkg.price}
                    onChange={(e) =>
                      updatePackage(pkg.id, {
                        price: parseFloat(e.target.value) || 0,
                      })
                    }
                  />
                  <Input
                    label="Color"
                    value={pkg.color || ''}
                    onChange={(e) =>
                      updatePackage(pkg.id, { color: e.target.value })
                    }
                  />
                  <Input
                    label="Turnaround Time"
                    value={pkg.turnaround || ''}
                    onChange={(e) =>
                      updatePackage(pkg.id, { turnaround: e.target.value })
                    }
                  />
                  <div className="md:col-span-2">
                    <TextArea
                      label="Includes (one per line)"
                      rows={3}
                      value={pkg.includes.join('\n')}
                      onChange={(e) =>
                        updatePackage(pkg.id, {
                          includes: e.target.value.split('\n').filter(Boolean),
                        })
                      }
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Input
                      label="Note (optional)"
                      value={pkg.note || ''}
                      onChange={(e) =>
                        updatePackage(pkg.id, { note: e.target.value })
                      }
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Add-Ons Section */}
        <section className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-2xl font-bold mb-6">Add-Ons</h2>

          <div className="space-y-4">
            {pricingData?.addOns.map((addOn) => (
              <div
                key={addOn.id}
                className="border border-gray-200 rounded-lg p-4"
              >
                <div className="grid md:grid-cols-3 gap-4">
                  <Input
                    label="Add-On Name"
                    value={addOn.name}
                    onChange={(e) =>
                      updateAddOn(addOn.id, { name: e.target.value })
                    }
                  />
                  <Input
                    label="Price"
                    type="number"
                    value={typeof addOn.price === 'number' ? addOn.price : ''}
                    onChange={(e) =>
                      updateAddOn(addOn.id, {
                        price: parseFloat(e.target.value) || 0,
                      })
                    }
                  />
                  <Select
                    label="Category"
                    value={addOn.category}
                    onChange={(e) =>
                      updateAddOn(addOn.id, {
                        category: e.target.value as 'digital' | 'printed' | 'special',
                      })
                    }
                    options={[
                      { value: 'digital', label: 'Digital' },
                      { value: 'printed', label: 'Printed' },
                      { value: 'special', label: 'Special' },
                    ]}
                  />
                  <div className="md:col-span-2">
                    <Input
                      label="Description"
                      value={addOn.description || ''}
                      onChange={(e) =>
                        updateAddOn(addOn.id, { description: e.target.value })
                      }
                    />
                  </div>
                  <Input
                    label="Note (optional)"
                    value={addOn.note || ''}
                    onChange={(e) =>
                      updateAddOn(addOn.id, { note: e.target.value })
                    }
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button
            onClick={handleSavePricing}
            isLoading={isLoading}
            className="px-8"
          >
            Save All Changes
          </Button>
        </div>
      </div>
    </main>
  )
}
