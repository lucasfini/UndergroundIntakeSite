'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/Header'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { TextArea } from '@/components/ui/TextArea'
import { Select } from '@/components/ui/Select'
import { FileUpload } from '@/components/ui/FileUpload'

interface FormErrors {
  [key: string]: string
}

export default function FormPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<FormErrors>({})

  const [formData, setFormData] = useState({
    service: '',
    name: '',
    position: '',
    email: '',
    eventName: '',
    time: '',
    eventDate: '',
    location: '',
    link: '',
    callToAction: '',
    content: '',
    additionalInfo: '',
  })

  const [logoFiles, setLogoFiles] = useState<File[]>([])
  const [attachmentFiles, setAttachmentFiles] = useState<File[]>([])

  const serviceOptions = [
    { value: 'avtek', label: 'Avtek' },
    { value: 'campus-events', label: 'Campus Events' },
    { value: 'cfmu', label: 'CFMU' },
    { value: 'child-care-centre', label: 'Child Care Centre' },
    { value: 'diversity-equity-network', label: 'Diversity + Equity Network' },
    { value: 'efrt', label: 'EFRT' },
    { value: 'food-collective-centre', label: 'Food Collective Centre' },
    { value: 'the-grind', label: 'The Grind' },
    { value: 'hotspot', label: 'HotSpot' },
    { value: 'macademics', label: 'Macademics' },
    { value: 'maccess', label: 'Maccess' },
    { value: 'maroons', label: 'Maroons' },
    { value: 'ombuds', label: 'Ombuds' },
    { value: 'pride-community-centre', label: 'Pride Community Centre' },
    { value: 'shec', label: 'SHEC' },
    { value: 'spark', label: 'Spark' },
    { value: 'swat', label: 'SWAT' },
    { value: 'the-silhouette', label: 'The Silhouette' },
    { value: 'twelve-eighty', label: 'Twelve Eighty' },
    { value: 'union-market', label: 'Union Market' },
    { value: 'wgen', label: 'WGEN' },
  ]

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }))
    }
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}

    // Required fields validation
    if (!formData.service) newErrors.service = 'Service is required'
    if (!formData.name) newErrors.name = 'Name is required'
    if (!formData.email) newErrors.email = 'Email is required'
    if (!formData.eventName) newErrors.eventName = 'Event name is required'
    if (!formData.eventDate) newErrors.eventDate = 'Event date is required'
    if (!formData.content) newErrors.content = 'Content description is required'

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (formData.email && !emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      window.scrollTo({ top: 0, behavior: 'smooth' })
      return
    }

    setIsLoading(true)

    try {
      // Create FormData for file uploads
      const submitData = new FormData()

      // Append form fields
      Object.entries(formData).forEach(([key, value]) => {
        submitData.append(key, value)
      })

      // Append files
      logoFiles.forEach((file) => {
        submitData.append('logos', file)
      })
      attachmentFiles.forEach((file) => {
        submitData.append('attachments', file)
      })

      const response = await fetch('/api/submit', {
        method: 'POST',
        body: submitData,
      })

      if (!response.ok) {
        throw new Error('Failed to submit form')
      }

      const result = await response.json()

      // Store uploaded file information
      const uploadedFiles = {
        logos: logoFiles.map(f => f.name),
        attachments: attachmentFiles.map(f => f.name),
      }

      // Redirect to add-ons page with form data in session storage
      sessionStorage.setItem('formData', JSON.stringify({
        ...formData,
        submissionId: result.id,
        uploadedFiles
      }))
      router.push('/add-ons')
    } catch (error) {
      console.error('Error submitting form:', error)
      alert('There was an error submitting your form. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      <Header currentPage="order" />

      {/* Form */}
      <div className="flex-1 max-w-4xl mx-auto px-6 py-12">
        {/* Date Submitted Notice */}
        <div className="bg-gray-50 border-l-4 border-underground-teal p-4 mb-8">
          <p className="text-sm text-gray-700">
            Email completed form to:{' '}
            <a href="mailto:ugmanager@msu.mcmaster.ca" className="font-medium text-underground-teal">
              ugmanager@msu.mcmaster.ca
            </a>
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Contact Info Section */}
          <section className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 pb-2 border-b-2 border-underground-teal">
              Contact Info
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Select
                  label="Service"
                  name="service"
                  value={formData.service}
                  onChange={handleInputChange}
                  options={serviceOptions}
                  error={errors.service}
                  required
                />
              </div>
              <Input
                label="Name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                error={errors.name}
                required
              />
              <Input
                label="Position"
                name="position"
                value={formData.position}
                onChange={handleInputChange}
              />
              <div className="md:col-span-2">
                <Input
                  label="Email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  error={errors.email}
                  required
                />
              </div>
            </div>
          </section>

          {/* Event Details Section */}
          <section className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 pb-2 border-b-2 border-underground-teal">
              Event Details
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <Input
                label="Event Name"
                name="eventName"
                value={formData.eventName}
                onChange={handleInputChange}
                error={errors.eventName}
                required
              />
              <Input
                label="Time"
                name="time"
                type="time"
                value={formData.time}
                onChange={handleInputChange}
              />
              <Input
                label="Event Date"
                name="eventDate"
                type="date"
                value={formData.eventDate}
                onChange={handleInputChange}
                error={errors.eventDate}
                required
              />
              <div>
                <FileUpload
                  label="Logos"
                  accept="image/*"
                  multiple
                  onChange={setLogoFiles}
                />
              </div>
              <Input
                label="Location"
                name="location"
                value={formData.location}
                onChange={handleInputChange}
              />
              <Input
                label="Link"
                name="link"
                type="url"
                placeholder="https://"
                value={formData.link}
                onChange={handleInputChange}
              />
            </div>
          </section>

          {/* Call To Action Section */}
          <section className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 pb-2 border-b-2 border-underground-teal">
              Call To Action
            </h2>
            <Input
              name="callToAction"
              placeholder="e.g., Register Now, Join Us, Learn More"
              value={formData.callToAction}
              onChange={handleInputChange}
            />
          </section>

          {/* Content Section */}
          <section className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 pb-2 border-b-2 border-underground-teal">
              Content
            </h2>
            <TextArea
              name="content"
              rows={6}
              placeholder="Describe the content you'd like to include in your design..."
              value={formData.content}
              onChange={handleInputChange}
              error={errors.content}
              required
            />
          </section>

          {/* Additional Info Section */}
          <section className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 pb-2 border-b-2 border-underground-teal">
              Additional links, references, QR codes or linktree
            </h2>
            <TextArea
              name="additionalInfo"
              rows={4}
              placeholder="Include any additional information, links, or references..."
              value={formData.additionalInfo}
              onChange={handleInputChange}
            />
            <div className="mt-4">
              <FileUpload
                label="Additional Attachments"
                accept="*"
                multiple
                onChange={setAttachmentFiles}
              />
            </div>
          </section>

          {/* Submit Button */}
          <div className="flex justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push('/')}
            >
              Cancel
            </Button>
            <Button type="submit" isLoading={isLoading}>
              Continue to Add-Ons
            </Button>
          </div>
        </form>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
