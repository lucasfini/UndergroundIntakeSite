import Link from 'next/link'
import Image from 'next/image'
import { Header } from '@/components/Header'

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      <Header currentPage="home" />

      {/* Hero Section with Background */}
      <section className="relative flex-1 flex items-center">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/Landing-Page-graphics-01.webp"
            alt="Underground Design Background"
            fill
            className="object-cover"
            priority
          />
          {/* Overlay for better text readability */}
          <div className="absolute inset-0 bg-white/30" />
        </div>

        {/* Content */}
        <div className="relative z-1 w-full max-w-7xl mx-auto px-6 py-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 drop-shadow-lg">
            Project Request Portal
          </h2>
          <p className="text-lg md:text-xl text-gray-800 max-w-2xl mx-auto drop-shadow-md">
            Submit your design project request and we'll get started on bringing your vision to life.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* New Project Card */}
          <Link
            href="/form"
            className="block p-8 bg-white/95 backdrop-blur-sm border-2 border-underground-teal rounded-lg hover:shadow-2xl transition-all hover:scale-105"
          >
            <div className="text-center">
              <div className="text-4xl mb-4">📝</div>
              <h3 className="text-2xl font-bold text-underground-teal mb-2">
                New Project Request
              </h3>
              <p className="text-gray-600">
                Fill out our project form to get started with your design needs
              </p>
            </div>
          </Link>

          {/* Contact Card */}
          <div className="p-8 bg-white/90 backdrop-blur-sm border-2 border-gray-300 rounded-lg hover:shadow-2xl transition-all">
            <div className="text-center">
              <div className="text-4xl mb-4">💬</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Questions?
              </h3>
              <p className="text-gray-600 mb-4">
                Contact us if you need assistance
              </p>
              <a
                href="mailto:ugmanager@msu.mcmaster.ca"
                className="text-underground-teal hover:underline font-medium"
              >
                ugmanager@msu.mcmaster.ca
              </a>
              <p className="text-sm text-gray-500 mt-4">
                Monday - Friday | 10am - 4pm
              </p>
            </div>
          </div>
        </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
