import { NextRequest, NextResponse } from 'next/server'
import { createZendeskTicket } from '@/lib/zendesk'
import { sendConfirmationEmail } from '@/lib/email'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Create Zendesk ticket
    let ticketId: string | undefined

    try {
      const zendeskResponse = await createZendeskTicket(data)
      ticketId = zendeskResponse.ticket?.id?.toString()
      console.log('Zendesk ticket created:', ticketId)
    } catch (error) {
      console.error('Failed to create Zendesk ticket:', error)
      // Continue even if Zendesk fails - we don't want to block the user
    }

    // Send confirmation email
    try {
      await sendConfirmationEmail(
        data.email,
        data.name,
        data.eventName,
        ticketId
      )
    } catch (error) {
      console.error('Failed to send confirmation email:', error)
      // Continue even if email fails
    }

    return NextResponse.json({
      success: true,
      ticketId,
      message: 'Request submitted successfully',
    })
  } catch (error) {
    console.error('Error submitting request:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to submit request' },
      { status: 500 }
    )
  }
}
