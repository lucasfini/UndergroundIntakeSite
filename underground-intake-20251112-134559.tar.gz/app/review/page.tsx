'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/Button'
import pricingData from '@/data/pricing.json'

interface FormData {
  service: string
  name: string
  position: string
  email: string
  eventName: string
  time: string
  eventDate: string
  location: string
  link: string
  callToAction: string
  content: string
  additionalInfo: string
  submissionId?: string
  uploadedFiles?: {
    logos: string[]
    attachments: string[]
  }
}

interface SelectedPackage {
  id: string
  name: string
  price: number
}

export default function ReviewPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState<FormData | null>(null)
  const [selectedPackage, setSelectedPackage] = useState<SelectedPackage | null>(null)
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([])
  const [totalPrice, setTotalPrice] = useState(0)

  useEffect(() => {
    // Load data from session storage
    const storedFormData = sessionStorage.getItem('formData')
    const storedPackage = sessionStorage.getItem('selectedPackage')
    const storedAddOns = sessionStorage.getItem('selectedAddOns')
    const storedTotal = sessionStorage.getItem('totalPrice')

    if (!storedFormData) {
      alert('No form data found. Please start from the beginning.')
      router.push('/form')
      return
    }

    setFormData(JSON.parse(storedFormData))
    setSelectedPackage(storedPackage ? JSON.parse(storedPackage) : null)
    setSelectedAddOns(storedAddOns ? JSON.parse(storedAddOns) : [])
    setTotalPrice(storedTotal ? parseFloat(storedTotal) : 0)
  }, [router])

  const getAddOnById = (id: string) => {
    return pricingData.addOns.find((a) => a.id === id)
  }

  const getServiceLabel = (value: string) => {
    const serviceMap: { [key: string]: string } = {
      'avtek': 'Avtek',
      'campus-events': 'Campus Events',
      'cfmu': 'CFMU',
      'child-care-centre': 'Child Care Centre',
      'diversity-equity-network': 'Diversity + Equity Network',
      'efrt': 'EFRT',
      'food-collective-centre': 'Food Collective Centre',
      'the-grind': 'The Grind',
      'hotspot': 'HotSpot',
      'macademics': 'Macademics',
      'maccess': 'Maccess',
      'maroons': 'Maroons',
      'ombuds': 'Ombuds',
      'pride-community-centre': 'Pride Community Centre',
      'shec': 'SHEC',
      'spark': 'Spark',
      'swat': 'SWAT',
      'the-silhouette': 'The Silhouette',
      'twelve-eighty': 'Twelve Eighty',
      'union-market': 'Union Market',
      'wgen': 'WGEN',
    }
    return serviceMap[value] || value
  }

  const handleSubmit = async () => {
    if (!formData) return

    setIsLoading(true)

    try {
      const submitData = {
        ...formData,
        selectedPackage,
        selectedAddOns,
        totalPrice,
      }

      const response = await fetch('/api/submit-complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(submitData),
      })

      if (!response.ok) {
        throw new Error('Failed to submit')
      }

      // Clear session storage
      sessionStorage.removeItem('formData')
      sessionStorage.removeItem('selectedPackage')
      sessionStorage.removeItem('selectedAddOns')
      sessionStorage.removeItem('totalPrice')

      router.push('/success')
    } catch (error) {
      console.error('Error submitting:', error)
      alert('There was an error submitting your request. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  if (!formData) {
    return (
      <main className="min-h-screen flex flex-col bg-white">
        <Header currentPage="order" />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-gray-600">Loading...</p>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      <Header currentPage="order" />

      <div className="flex-1 max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold mb-8 text-center">Review Your Order</h1>

        {/* Contact Information */}
        <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
            Contact Information
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Service</p>
              <p className="font-medium">{getServiceLabel(formData.service)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Name</p>
              <p className="font-medium">{formData.name}</p>
            </div>
            {formData.position && (
              <div>
                <p className="text-sm text-gray-600">Position</p>
                <p className="font-medium">{formData.position}</p>
              </div>
            )}
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="font-medium">{formData.email}</p>
            </div>
          </div>
        </section>

        {/* Event Details */}
        <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
            Event Details
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Event Name</p>
              <p className="font-medium">{formData.eventName}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Event Date</p>
              <p className="font-medium">{formData.eventDate}</p>
            </div>
            {formData.time && (
              <div>
                <p className="text-sm text-gray-600">Time</p>
                <p className="font-medium">{formData.time}</p>
              </div>
            )}
            {formData.location && (
              <div>
                <p className="text-sm text-gray-600">Location</p>
                <p className="font-medium">{formData.location}</p>
              </div>
            )}
            {formData.link && (
              <div className="md:col-span-2">
                <p className="text-sm text-gray-600">Link</p>
                <p className="font-medium break-all">
                  <a
                    href={formData.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-underground-teal hover:underline"
                  >
                    {formData.link}
                  </a>
                </p>
              </div>
            )}
          </div>
        </section>

        {/* Call to Action */}
        {formData.callToAction && (
          <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
              Call To Action
            </h2>
            <p className="font-medium">{formData.callToAction}</p>
          </section>
        )}

        {/* Content */}
        <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
            Content
          </h2>
          <p className="whitespace-pre-wrap">{formData.content}</p>
        </section>

        {/* Additional Info */}
        {formData.additionalInfo && (
          <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
              Additional Information
            </h2>
            <p className="whitespace-pre-wrap">{formData.additionalInfo}</p>
          </section>
        )}

        {/* Uploaded Files */}
        {formData.uploadedFiles && (formData.uploadedFiles.logos.length > 0 || formData.uploadedFiles.attachments.length > 0) && (
          <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
              Uploaded Files
            </h2>
            {formData.uploadedFiles.logos.length > 0 && (
              <div className="mb-4">
                <p className="font-semibold mb-2">Logos:</p>
                <ul className="list-disc list-inside space-y-1">
                  {formData.uploadedFiles.logos.map((file, idx) => (
                    <li key={idx} className="text-gray-700">{file}</li>
                  ))}
                </ul>
              </div>
            )}
            {formData.uploadedFiles.attachments.length > 0 && (
              <div>
                <p className="font-semibold mb-2">Attachments:</p>
                <ul className="list-disc list-inside space-y-1">
                  {formData.uploadedFiles.attachments.map((file, idx) => (
                    <li key={idx} className="text-gray-700">{file}</li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        )}

        {/* Selected Package */}
        {selectedPackage && (
          <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
              Selected Package
            </h2>
            <div className="flex justify-between items-center">
              <span className="font-medium text-lg">{selectedPackage.name}</span>
              <span className="text-underground-teal font-bold text-xl">
                ${selectedPackage.price}
              </span>
            </div>
          </section>
        )}

        {/* Selected Add-Ons */}
        {selectedAddOns.length > 0 && (
          <section className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-underground-teal">
              Selected Add-Ons
            </h2>
            <ul className="space-y-2">
              {selectedAddOns.map((addOnId) => {
                const addOn = getAddOnById(addOnId)
                if (!addOn) return null
                return (
                  <li key={addOnId} className="flex justify-between items-center">
                    <span className="font-medium">{addOn.name}</span>
                    <span className="text-underground-teal font-bold">
                      {addOn.note || `$${addOn.price}`}
                    </span>
                  </li>
                )
              })}
            </ul>
          </section>
        )}

        {/* Total Price */}
        <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-6 mb-8">
          <div className="flex justify-between items-center">
            <h3 className="text-2xl font-bold">Estimated Total</h3>
            <p className="text-4xl font-bold text-underground-teal">${totalPrice}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between gap-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.push('/add-ons')}
          >
            Back to Add-Ons
          </Button>
          <Button onClick={handleSubmit} isLoading={isLoading}>
            Submit Request
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
