'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/Button'
import pricingData from '@/data/pricing.json'

interface SelectedPackage {
  id: string
  name: string
  price: number
}

export default function AddOnsPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [selectedPackage, setSelectedPackage] = useState<SelectedPackage | null>(null)
  const [selectedAddOns, setSelectedAddOns] = useState<Set<string>>(new Set())

  const toggleAddOn = (addOnId: string) => {
    const newSelection = new Set(selectedAddOns)
    if (newSelection.has(addOnId)) {
      newSelection.delete(addOnId)
    } else {
      newSelection.add(addOnId)
    }
    setSelectedAddOns(newSelection)
  }

  const calculateTotal = (): number => {
    let total = selectedPackage?.price || 0

    selectedAddOns.forEach((addOnId) => {
      const addOn = pricingData.addOns.find((a) => a.id === addOnId)
      if (addOn && typeof addOn.price === 'number') {
        total += addOn.price
      }
    })

    return total
  }

  const handleContinue = () => {
    const formData = sessionStorage.getItem('formData')
    if (!formData) {
      alert('Form data not found. Please fill out the form first.')
      router.push('/form')
      return
    }

    // Store selected package and add-ons in session storage
    sessionStorage.setItem('selectedPackage', JSON.stringify(selectedPackage))
    sessionStorage.setItem('selectedAddOns', JSON.stringify(Array.from(selectedAddOns)))
    sessionStorage.setItem('totalPrice', calculateTotal().toString())

    // Navigate to review page
    router.push('/review')
  }

  const getColorClass = (color?: string) => {
    switch (color) {
      case 'blue':
        return 'border-blue-600 bg-blue-50'
      case 'green':
        return 'border-green-600 bg-green-50'
      case 'red':
        return 'border-red-600 bg-red-50'
      case 'yellow':
        return 'border-yellow-500 bg-yellow-50'
      default:
        return 'border-gray-300 bg-gray-50'
    }
  }

  const getHeaderColorClass = (color?: string) => {
    switch (color) {
      case 'blue':
        return 'bg-blue-600'
      case 'green':
        return 'bg-green-600'
      case 'red':
        return 'bg-red-600'
      case 'yellow':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-600'
    }
  }

  const digitalAddOns = pricingData.addOns.filter((a) => a.category === 'digital' && a.id !== 'digital-graphics')
  const printedAddOns = pricingData.addOns.filter((a) => a.category === 'printed')
  const specialAddOns = pricingData.addOns.filter((a) => a.category === 'special')

  return (
    <main className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      <Header currentPage="order" />

      <div className="flex-1 max-w-7xl mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Packages */}
          <div>
            <h2 className="text-3xl font-bold mb-6">Select a Package</h2>

            <div className="space-y-4">
              {pricingData.packages.map((pkg) => (
                <div
                  key={pkg.id}
                  onClick={() =>
                    setSelectedPackage({
                      id: pkg.id,
                      name: pkg.name,
                      price: pkg.price,
                    })
                  }
                  className={`border-2 rounded-lg overflow-hidden cursor-pointer transition-all ${
                    selectedPackage?.id === pkg.id
                      ? 'ring-4 ring-underground-teal ring-opacity-50'
                      : ''
                  } ${getColorClass(pkg.color)}`}
                >
                  <div
                    className={`${getHeaderColorClass(
                      pkg.color
                    )} text-white px-4 py-3 flex justify-between items-center`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        checked={selectedPackage?.id === pkg.id}
                        onChange={() =>
                          setSelectedPackage({
                            id: pkg.id,
                            name: pkg.name,
                            price: pkg.price,
                          })
                        }
                        className="w-5 h-5"
                      />
                      <h3 className="text-xl font-bold">{pkg.name}</h3>
                    </div>
                    <span className="text-2xl font-bold">
                      {pkg.id === 'self-serve' ? `$${pkg.price}` : (pkg.note || `$${pkg.price}`)}
                    </span>
                  </div>

                  <div className="p-4">
                    {pkg.includes.length > 0 && (
                      <>
                        <p className="font-semibold mb-2">Includes:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          {pkg.includes.map((item, idx) => (
                            <li key={idx}>{item}</li>
                          ))}
                        </ul>
                      </>
                    )}
                    {pkg.turnaround && pkg.id !== 'self-serve' && (
                      <p className="text-sm italic mt-2">*{pkg.turnaround}</p>
                    )}
                    {pkg.note && pkg.id === 'self-serve' && (
                      <div className="flex items-start gap-3 text-sm text-gray-700">
                        <span className="text-yellow-600 text-xl flex-shrink-0">⚠️</span>
                        <p>{pkg.note}</p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column - Add-Ons */}
          <div>
            <h2 className="text-3xl font-bold mb-6">Add-Ons</h2>

            {/* Digital Graphics */}
            <div className="mb-6">
              <h3 className="text-xl font-bold bg-underground-teal text-white px-4 py-2 rounded-t">
                Digital Graphics
              </h3>
              <div className="border-2 border-underground-teal rounded-b p-4 space-y-3">
                {digitalAddOns.map((addOn) => (
                  <label
                    key={addOn.id}
                    className="flex items-start gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded"
                  >
                    <input
                      type="checkbox"
                      checked={selectedAddOns.has(addOn.id)}
                      onChange={() => toggleAddOn(addOn.id)}
                      className="mt-1 w-5 h-5"
                      disabled={addOn.note === 'Included in packages'}
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <span className="font-medium">{addOn.name}</span>
                        <span className="font-bold text-underground-teal">
                          {addOn.note || `$${addOn.price}`}
                        </span>
                      </div>
                      {addOn.description && (
                        <p className="text-sm text-gray-600 mt-1">
                          {addOn.description}
                        </p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Printed Media */}
            <div className="mb-6">
              <h3 className="text-xl font-bold bg-underground-teal text-white px-4 py-2 rounded-t">
                Printed Media
              </h3>
              <div className="border-2 border-underground-teal rounded-b p-4 space-y-3">
                {printedAddOns.map((addOn) => (
                  <label
                    key={addOn.id}
                    className="flex items-start gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded"
                  >
                    <input
                      type="checkbox"
                      checked={selectedAddOns.has(addOn.id)}
                      onChange={() => toggleAddOn(addOn.id)}
                      className="mt-1 w-5 h-5"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <span className="font-medium">{addOn.name}</span>
                        <span className="font-bold text-underground-teal">
                          ${addOn.price}
                        </span>
                      </div>
                      {addOn.description && (
                        <p className="text-sm text-gray-600 mt-1">
                          {addOn.description}
                        </p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Special Orders */}
            <div className="mb-6">
              <h3 className="text-xl font-bold bg-underground-teal text-white px-4 py-2 rounded-t">
                Special Orders
              </h3>
              <div className="border-2 border-underground-teal rounded-b p-4 space-y-3">
                {specialAddOns.map((addOn) => (
                  <label
                    key={addOn.id}
                    className="flex items-start gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded"
                  >
                    <input
                      type="checkbox"
                      checked={selectedAddOns.has(addOn.id)}
                      onChange={() => toggleAddOn(addOn.id)}
                      className="mt-1 w-5 h-5"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <span className="font-medium">{addOn.name}</span>
                        <span className="font-bold text-underground-teal">
                          {addOn.note || `$${addOn.price}`}
                        </span>
                      </div>
                      {addOn.description && (
                        <p className="text-sm text-gray-600 mt-1">
                          {addOn.description}
                        </p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Turnaround Notice */}
            <div className="bg-underground-teal text-white p-4 rounded-lg">
              <p className="text-sm italic">
                *Turnaround times begin once your request is received and may be adjusted
                based on project volume and complexity.
              </p>
            </div>
          </div>
        </div>

        {/* Total and Continue */}
        <div className="mt-12 bg-gray-50 border-2 border-gray-200 rounded-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-2xl font-bold">Order Summary</h3>
              {selectedPackage && (
                <p className="text-gray-600 mt-1">
                  Package: {selectedPackage.name}
                </p>
              )}
              {selectedAddOns.size > 0 && (
                <p className="text-gray-600">
                  Add-ons selected: {selectedAddOns.size}
                </p>
              )}
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Estimated Total</p>
              <p className="text-4xl font-bold text-underground-teal">
                ${calculateTotal()}
              </p>
            </div>
          </div>

          <div className="flex justify-between gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push('/form')}
            >
              Back to Form
            </Button>
            <Button
              onClick={handleContinue}
              disabled={!selectedPackage}
            >
              Continue to Review
            </Button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
