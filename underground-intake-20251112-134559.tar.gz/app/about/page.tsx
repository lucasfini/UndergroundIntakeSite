import Link from 'next/link'
import { Header } from '@/components/Header'

export default function AboutPage() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      <Header currentPage="about" />

      <div className="flex-1 max-w-4xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-6">About Us</h1>

        <div className="prose max-w-none">
          <p className="text-lg text-gray-600 mb-8">
            Underground Design is McMaster Student Union's in-house design, media, and print service.
          </p>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What We Do</h2>
            <p className="text-gray-700 mb-4">
              We provide comprehensive design services to MSU clubs, services, and the McMaster community. From social media graphics to large-scale print projects, we bring your vision to life.
            </p>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Services</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Social Media Graphics (Instagram, Facebook, Twitter)</li>
              <li>Event Posters and Promotional Materials</li>
              <li>Digital Displays and Campus Screen Graphics</li>
              <li>Print Services (Posters, Banners, Stickers, Brochures)</li>
              <li>Branding and Logo Design</li>
              <li>Custom Design Projects</li>
            </ul>
          </div>

          <div className="bg-underground-teal/10 border-l-4 border-underground-teal p-6 rounded mb-8">
            <h2 className="text-xl font-bold text-gray-900 mb-2">Office Hours</h2>
            <p className="text-gray-700 mb-2">
              Monday - Friday | 10am - 4pm
            </p>
            <p className="text-gray-700">
              Email: <a href="mailto:ugmanager@msu.mcmaster.ca" className="text-underground-teal">ugmanager@msu.mcmaster.ca</a>
            </p>
          </div>

          <div className="text-center">
            <Link
              href="/form"
              className="inline-block bg-underground-teal text-white px-8 py-3 rounded hover:bg-underground-green transition"
            >
              Start Your Project
            </Link>
          </div>
        </div>
      </div>

      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
