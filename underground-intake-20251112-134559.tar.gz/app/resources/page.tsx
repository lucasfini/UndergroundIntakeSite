import Link from 'next/link'
import { Header } from '@/components/Header'

export default function ResourcesPage() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      <Header currentPage="resources" />

      <div className="flex-1 max-w-4xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-6">Resources</h1>

        <div className="prose max-w-none">
          <p className="text-lg text-gray-600 mb-8">
            Find helpful resources and guidelines for working with Underground Design.
          </p>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="border border-gray-200 rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-3">Brand Guidelines</h2>
              <p className="text-gray-600 mb-4">
                Learn about MSU branding standards and how to use logos properly.
              </p>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-3">Design Templates</h2>
              <p className="text-gray-600 mb-4">
                Access Canva templates for quick self-service design projects.
              </p>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-3">FAQs</h2>
              <p className="text-gray-600 mb-4">
                Common questions about turnaround times, file formats, and more.
              </p>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-3">Support</h2>
              <p className="text-gray-600 mb-4">
                Need help? Contact us at{' '}
                <a href="mailto:ugmanager@msu.mcmaster.ca" className="text-underground-teal">
                  ugmanager@msu.mcmaster.ca
                </a>
              </p>
            </div>
          </div>

          <div className="bg-underground-teal/10 border-l-4 border-underground-teal p-6 rounded">
            <h2 className="text-xl font-bold text-gray-900 mb-2">Ready to Start?</h2>
            <p className="text-gray-700 mb-4">
              Submit your project request and our team will guide you through the process.
            </p>
            <Link
              href="/form"
              className="inline-block bg-underground-teal text-white px-6 py-3 rounded hover:bg-underground-green transition"
            >
              Submit Project Request
            </Link>
          </div>
        </div>
      </div>

      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
