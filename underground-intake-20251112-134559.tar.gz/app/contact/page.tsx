import Link from 'next/link'
import { Header } from '@/components/Header'

export default function ContactPage() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      <Header currentPage="contact" />

      <div className="flex-1 max-w-4xl mx-auto px-6 py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-6">Contact Us</h1>

        <div className="prose max-w-none">
          <p className="text-lg text-gray-600 mb-8">
            Have questions about your project? We're here to help!
          </p>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div className="border border-gray-200 rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Get in Touch</h2>
              <div className="space-y-4 text-gray-700">
                <div>
                  <h3 className="font-semibold mb-1">Email</h3>
                  <a
                    href="mailto:ugmanager@msu.mcmaster.ca"
                    className="text-underground-teal hover:underline"
                  >
                    ugmanager@msu.mcmaster.ca
                  </a>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Office Hours</h3>
                  <p>Monday - Friday</p>
                  <p>10:00 AM - 4:00 PM</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Location</h3>
                  <p>McMaster Student Union</p>
                  <p>McMaster University</p>
                  <p>Hamilton, ON</p>
                </div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-6 bg-gray-50">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Submit a Project</h2>
              <p className="text-gray-700 mb-4">
                The fastest way to get started is by submitting a project request through our online form.
              </p>
              <Link
                href="/form"
                className="inline-block bg-underground-teal text-white px-6 py-3 rounded hover:bg-underground-green transition"
              >
                Submit Project Request
              </Link>
            </div>
          </div>

          <div className="bg-underground-teal/10 border-l-4 border-underground-teal p-6 rounded">
            <h2 className="text-xl font-bold text-gray-900 mb-2">Response Time</h2>
            <p className="text-gray-700">
              We typically respond to all inquiries within 1-2 business days. For urgent requests, please mention "URGENT" in your email subject line.
            </p>
          </div>
        </div>
      </div>

      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm opacity-75">
            © 2024 Underground Design - McMaster Student Union
          </p>
        </div>
      </footer>
    </main>
  )
}
